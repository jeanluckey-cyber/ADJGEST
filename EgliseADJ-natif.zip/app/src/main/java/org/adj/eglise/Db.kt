package org.adj.eglise

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

// Même structure que la base Access : tblParametre, tblCategorie, tblActivite, tblCaisse, tblFrequentation.

data class Cat(val id: Long, val libelle: String)
data class Op(
    val id: Long, val dateOp: String, val typeOp: String, val catId: Long,
    val montant: Double, val devise: String, val note: String
)
data class Freq(
    val id: Long, val dateAct: String, val actId: Long,
    val adF: Int, val adS: Int, val jeF: Int, val jeS: Int, val enf: Int,
    val lieu: String, val intervenant: String, val observation: String
) {
    val total: Int get() = adF + adS + jeF + jeS + enf
}

class Db(ctx: Context) : SQLiteOpenHelper(ctx, "eglise_adj.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE tblParametre (IDParam INTEGER PRIMARY KEY, NomEglise TEXT)")
        db.execSQL("CREATE TABLE tblCategorie (IDCategorie INTEGER PRIMARY KEY AUTOINCREMENT, Libelle TEXT NOT NULL)")
        db.execSQL("CREATE TABLE tblActivite (IDActivite INTEGER PRIMARY KEY AUTOINCREMENT, Libelle TEXT NOT NULL)")
        db.execSQL(
            "CREATE TABLE tblCaisse (IDCaisse INTEGER PRIMARY KEY AUTOINCREMENT, DateOp TEXT NOT NULL, " +
                "TypeOp TEXT NOT NULL, IDCategorie INTEGER NOT NULL, Montant REAL NOT NULL, " +
                "Devise TEXT NOT NULL, Note TEXT)"
        )
        db.execSQL(
            "CREATE TABLE tblFrequentation (IDFreq INTEGER PRIMARY KEY AUTOINCREMENT, DateAct TEXT NOT NULL, " +
                "IDActivite INTEGER NOT NULL, AdultesFreres INTEGER, AdultesSoeurs INTEGER, JeunesFreres INTEGER, " +
                "JeunesSoeurs INTEGER, Enfants INTEGER, Lieu TEXT, Intervenant TEXT, Observation TEXT)"
        )
        db.execSQL("INSERT INTO tblParametre (IDParam, NomEglise) VALUES (1, 'A.D.J/HEWA BORA/LUBUMBASHI')")
        listOf(
            "Dîme", "Offrandes", "Dons", "Construction", "Entretien",
            "Aide sociale", "Transport des frères et soeurs", "Autres"
        ).forEach { db.execSQL("INSERT INTO tblCategorie (Libelle) VALUES (?)", arrayOf(it)) }
        listOf("Enseignement", "Prière", "Prière à jeûne", "Évangélisation", "Culte de consolation")
            .forEach { db.execSQL("INSERT INTO tblActivite (Libelle) VALUES (?)", arrayOf(it)) }
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    // ---- Paramètre
    fun eglise(): String {
        readableDatabase.rawQuery("SELECT NomEglise FROM tblParametre WHERE IDParam=1", null).use {
            return if (it.moveToFirst()) it.getString(0) ?: "" else ""
        }
    }

    fun setEglise(nom: String) {
        val v = ContentValues().apply { put("IDParam", 1); put("NomEglise", nom) }
        writableDatabase.insertWithOnConflict("tblParametre", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }

    // ---- Catégories / activités (même code, deux tables)
    private fun refs(table: String, idCol: String): List<Cat> {
        val out = ArrayList<Cat>()
        readableDatabase.rawQuery("SELECT $idCol, Libelle FROM $table ORDER BY $idCol", null).use {
            while (it.moveToNext()) out.add(Cat(it.getLong(0), it.getString(1)))
        }
        return out
    }

    private fun saveRef(table: String, idCol: String, id: Long, libelle: String) {
        val v = ContentValues().apply { put("Libelle", libelle) }
        if (id == 0L) writableDatabase.insert(table, null, v)
        else writableDatabase.update(table, v, "$idCol=?", arrayOf(id.toString()))
    }

    private fun count(sql: String, id: Long): Int =
        readableDatabase.rawQuery(sql, arrayOf(id.toString())).use { if (it.moveToFirst()) it.getInt(0) else 0 }

    fun cats() = refs("tblCategorie", "IDCategorie")
    fun acts() = refs("tblActivite", "IDActivite")
    fun saveCat(id: Long, l: String) = saveRef("tblCategorie", "IDCategorie", id, l)
    fun saveAct(id: Long, l: String) = saveRef("tblActivite", "IDActivite", id, l)
    fun catUsage(id: Long) = count("SELECT COUNT(*) FROM tblCaisse WHERE IDCategorie=?", id)
    fun actUsage(id: Long) = count("SELECT COUNT(*) FROM tblFrequentation WHERE IDActivite=?", id)
    fun delCat(id: Long) { writableDatabase.delete("tblCategorie", "IDCategorie=?", arrayOf(id.toString())) }
    fun delAct(id: Long) { writableDatabase.delete("tblActivite", "IDActivite=?", arrayOf(id.toString())) }

    // ---- Caisse
    private fun op(c: Cursor) = Op(
        c.getLong(0), c.getString(1), c.getString(2), c.getLong(3),
        c.getDouble(4), c.getString(5), c.getString(6) ?: ""
    )

    fun ops(): List<Op> {
        val out = ArrayList<Op>()
        readableDatabase.rawQuery(
            "SELECT IDCaisse, DateOp, TypeOp, IDCategorie, Montant, Devise, Note FROM tblCaisse " +
                "ORDER BY DateOp DESC, IDCaisse DESC", null
        ).use { while (it.moveToNext()) out.add(op(it)) }
        return out
    }

    fun saveOp(o: Op) {
        val v = ContentValues().apply {
            put("DateOp", o.dateOp); put("TypeOp", o.typeOp); put("IDCategorie", o.catId)
            put("Montant", o.montant); put("Devise", o.devise); put("Note", o.note)
        }
        if (o.id == 0L) writableDatabase.insert("tblCaisse", null, v)
        else writableDatabase.update("tblCaisse", v, "IDCaisse=?", arrayOf(o.id.toString()))
    }

    fun delOp(id: Long) { writableDatabase.delete("tblCaisse", "IDCaisse=?", arrayOf(id.toString())) }

    // ---- Fréquentation
    fun freqs(): List<Freq> {
        val out = ArrayList<Freq>()
        readableDatabase.rawQuery(
            "SELECT IDFreq, DateAct, IDActivite, AdultesFreres, AdultesSoeurs, JeunesFreres, JeunesSoeurs, " +
                "Enfants, Lieu, Intervenant, Observation FROM tblFrequentation ORDER BY DateAct DESC, IDFreq DESC", null
        ).use {
            while (it.moveToNext()) out.add(
                Freq(
                    it.getLong(0), it.getString(1), it.getLong(2),
                    it.getInt(3), it.getInt(4), it.getInt(5), it.getInt(6), it.getInt(7),
                    it.getString(8) ?: "", it.getString(9) ?: "", it.getString(10) ?: ""
                )
            )
        }
        return out
    }

    fun saveFreq(f: Freq) {
        val v = ContentValues().apply {
            put("DateAct", f.dateAct); put("IDActivite", f.actId)
            put("AdultesFreres", f.adF); put("AdultesSoeurs", f.adS)
            put("JeunesFreres", f.jeF); put("JeunesSoeurs", f.jeS); put("Enfants", f.enf)
            put("Lieu", f.lieu); put("Intervenant", f.intervenant); put("Observation", f.observation)
        }
        if (f.id == 0L) writableDatabase.insert("tblFrequentation", null, v)
        else writableDatabase.update("tblFrequentation", v, "IDFreq=?", arrayOf(f.id.toString()))
    }

    fun delFreq(id: Long) { writableDatabase.delete("tblFrequentation", "IDFreq=?", arrayOf(id.toString())) }
}
