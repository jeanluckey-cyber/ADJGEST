package org.adj.eglise

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = Db(this)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF2B4EA2))) {
                App(db)
            }
        }
    }
}

@Composable
fun App(db: Db) {
    var tab by remember { mutableIntStateOf(0) }
    var tick by remember { mutableIntStateOf(0) }
    val bump: () -> Unit = { tick++ }
    val labels = listOf("Accueil", "Caisse", "Présences", "Rapports", "Réglages")
    val icons = listOf(Icons.Default.Home, Icons.Default.ShoppingCart, Icons.Default.Person, Icons.Default.DateRange, Icons.Default.Settings)
    Scaffold(
        bottomBar = {
            NavigationBar {
                labels.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Icon(icons[i], contentDescription = t) },
                        label = { Text(t, fontSize = 11.sp, maxLines = 1) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                0 -> HomeScreen(db, tick, bump) { tab = it }
                1 -> CaisseScreen(db, tick, bump)
                2 -> FreqScreen(db, tick, bump)
                3 -> RapportScreen(db, tick)
                else -> ReglageScreen(db, tick, bump)
            }
        }
    }
}
