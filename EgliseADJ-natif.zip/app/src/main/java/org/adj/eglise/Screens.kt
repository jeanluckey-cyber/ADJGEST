package org.adj.eglise

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

private val Vert = Color(0xFF1B7F4B)
private val Rouge = Color(0xFFB3362F)

// ======================= ACCUEIL =======================
@Composable
fun HomeScreen(db: Db, tick: Int, bump: () -> Unit, go: (Int) -> Unit) {
    val ops = remember(tick) { db.ops() }
    val freqs = remember(tick) { db.freqs() }
    val cats = remember(tick) { db.cats() }
    val acts = remember(tick) { db.acts() }
    var opDlg by remember { mutableStateOf<Op?>(null) }
    var frDlg by remember { mutableStateOf<Freq?>(null) }
    val debut = monthStart(); val fin = today()
    val mois = ops.filter { it.dateOp in debut..fin }
    val fm = freqs.filter { it.dateAct in debut..fin }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text(db.eglise(), style = MaterialTheme.typography.labelLarge) }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    val now = java.util.Calendar.getInstance()
                    Text("Caisse, ${MOIS[now.get(java.util.Calendar.MONTH)]} ${now.get(java.util.Calendar.YEAR)}", style = MaterialTheme.typography.titleMedium)
                    DEVISES.forEach { d ->
                        val e = mois.filter { it.devise == d && it.typeOp == "Entrée" }.sumOf { it.montant }
                        val s = mois.filter { it.devise == d && it.typeOp == "Sortie" }.sumOf { it.montant }
                        Spacer(Modifier.height(10.dp))
                        Text("Solde $d", style = MaterialTheme.typography.labelMedium)
                        Text(fmt(e - s), style = MaterialTheme.typography.headlineSmall, color = if (e - s < 0) Rouge else Color.Unspecified)
                        Text("Entrées ${fmt(e)}   ·   Sorties ${fmt(s)}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { opDlg = Op(0, today(), "Entrée", cats.firstOrNull()?.id ?: 0, 0.0, "CDF", "") }, modifier = Modifier.weight(1f)) { Text("+ Entrée", color = Vert) }
                OutlinedButton(onClick = { opDlg = Op(0, today(), "Sortie", cats.firstOrNull()?.id ?: 0, 0.0, "CDF", "") }, modifier = Modifier.weight(1f)) { Text("+ Sortie", color = Rouge) }
                Button(onClick = { frDlg = Freq(0, today(), acts.firstOrNull()?.id ?: 0, 0, 0, 0, 0, 0, "", "", "") }, modifier = Modifier.weight(1f)) { Text("+ Activité") }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Fréquentation du mois", style = MaterialTheme.typography.labelMedium)
                    Text("${fm.sumOf { it.total }} personnes sur ${fm.size} activité(s)", style = MaterialTheme.typography.titleMedium)
                }
            }
        }
        item { Text("Dernières opérations", style = MaterialTheme.typography.titleMedium) }
        if (ops.isEmpty()) item { Text("Aucune opération enregistrée.", style = MaterialTheme.typography.bodyMedium) }
        items(ops.take(5)) { OpRow(it, cats) { o -> opDlg = o } }
        item { TextButton(onClick = { go(1) }) { Text("Tout voir") } }
    }
    opDlg?.let { OpDialog(db, it, { opDlg = null }) { opDlg = null; bump() } }
    frDlg?.let { FreqDialog(db, it, { frDlg = null }) { frDlg = null; bump() } }
}

@Composable
fun OpRow(o: Op, cats: List<Cat>, onClick: (Op) -> Unit) {
    val ent = o.typeOp == "Entrée"
    Column(Modifier.fillMaxWidth().clickable { onClick(o) }.padding(vertical = 8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(cats.firstOrNull { it.id == o.catId }?.libelle ?: "(catégorie supprimée)", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Text((if (ent) "+" else "−") + fmt(o.montant) + " " + o.devise, color = if (ent) Vert else Rouge, fontWeight = FontWeight.Bold)
        }
        Text(fdate(o.dateOp) + (if (o.note.isNotBlank()) " · " + o.note else ""), style = MaterialTheme.typography.bodySmall)
        HorizontalDivider(Modifier.padding(top = 8.dp))
    }
}

// ======================= CAISSE =======================
@Composable
fun CaisseScreen(db: Db, tick: Int, bump: () -> Unit) {
    val ops = remember(tick) { db.ops() }
    val cats = remember(tick) { db.cats() }
    var type by remember { mutableStateOf("Tous") }
    var dev by remember { mutableStateOf("Toutes") }
    var dlg by remember { mutableStateOf<Op?>(null) }
    val shown = ops.filter { (type == "Tous" || it.typeOp == type) && (dev == "Toutes" || it.devise == dev) }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { dlg = Op(0, today(), "Entrée", cats.firstOrNull()?.id ?: 0, 0.0, "CDF", "") }, modifier = Modifier.weight(1f)) { Text("+ Entrée", color = Vert) }
            OutlinedButton(onClick = { dlg = Op(0, today(), "Sortie", cats.firstOrNull()?.id ?: 0, 0.0, "CDF", "") }, modifier = Modifier.weight(1f)) { Text("+ Sortie", color = Rouge) }
        }
        Spacer(Modifier.height(8.dp))
        Chips(listOf("Tous", "Entrée", "Sortie"), type, { it }) { type = it }
        Spacer(Modifier.height(4.dp))
        Chips(listOf("Toutes", "CDF", "USD"), dev, { it }) { dev = it }
        Spacer(Modifier.height(8.dp))
        if (shown.isEmpty()) Text("Aucune opération.")
        LazyColumn(Modifier.fillMaxSize()) { items(shown) { OpRow(it, cats) { o -> dlg = o } } }
    }
    dlg?.let { OpDialog(db, it, { dlg = null }) { dlg = null; bump() } }
}

@Composable
fun OpDialog(db: Db, init: Op, onClose: () -> Unit, onSaved: () -> Unit) {
    val cats = remember { db.cats() }
    var o by remember { mutableStateOf(init) }
    var m by remember { mutableStateOf(if (init.id == 0L) "" else trimNum(init.montant)) }
    var err by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (init.id == 0L) "Nouvelle opération" else "Modifier l’opération") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Chips(listOf("Entrée", "Sortie"), o.typeOp, { it }) { o = o.copy(typeOp = it) }
                DateField("Date", o.dateOp, { o = o.copy(dateOp = it) })
                Pick("Catégorie", cats, cats.firstOrNull { it.id == o.catId }, { it.libelle }) { o = o.copy(catId = it.id) }
                OutlinedTextField(
                    value = m, onValueChange = { m = it }, label = { Text("Montant") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth()
                )
                Chips(DEVISES, o.devise, { it }) { o = o.copy(devise = it) }
                OutlinedTextField(value = o.note, onValueChange = { o = o.copy(note = it) }, label = { Text("Note") }, modifier = Modifier.fillMaxWidth())
                err?.let { Text(it, color = Rouge) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val v = m.replace(',', '.').toDoubleOrNull()
                when {
                    cats.none { it.id == o.catId } -> err = "Choisissez une catégorie."
                    v == null || v <= 0 -> err = "Saisissez un montant supérieur à zéro."
                    else -> { db.saveOp(o.copy(montant = v)); onSaved() }
                }
            }) { Text("Enregistrer") }
        },
        dismissButton = {
            Row {
                if (init.id != 0L) TextButton(onClick = { if (confirm) { db.delOp(init.id); onSaved() } else confirm = true }) {
                    Text(if (confirm) "Confirmer" else "Supprimer", color = Rouge)
                }
                TextButton(onClick = onClose) { Text("Annuler") }
            }
        }
    )
}

// ======================= FRÉQUENTATION =======================
@Composable
fun FreqScreen(db: Db, tick: Int, bump: () -> Unit) {
    val freqs = remember(tick) { db.freqs() }
    val acts = remember(tick) { db.acts() }
    var dlg by remember { mutableStateOf<Freq?>(null) }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Button(onClick = { dlg = Freq(0, today(), acts.firstOrNull()?.id ?: 0, 0, 0, 0, 0, 0, "", "", "") }, modifier = Modifier.fillMaxWidth()) { Text("+ Nouvelle activité") }
        Spacer(Modifier.height(8.dp))
        if (freqs.isEmpty()) Text("Aucune activité enregistrée.")
        LazyColumn(Modifier.fillMaxSize()) {
            items(freqs) { f ->
                Column(Modifier.fillMaxWidth().clickable { dlg = f }.padding(vertical = 8.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(acts.firstOrNull { it.id == f.actId }?.libelle ?: "(activité supprimée)", fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                        Text("${f.total} pers.", fontWeight = FontWeight.Bold)
                    }
                    Text(listOf(fdate(f.dateAct), f.lieu, f.intervenant).filter { it.isNotBlank() }.joinToString(" · "), style = MaterialTheme.typography.bodySmall)
                    HorizontalDivider(Modifier.padding(top = 8.dp))
                }
            }
        }
    }
    dlg?.let { FreqDialog(db, it, { dlg = null }) { dlg = null; bump() } }
}

@Composable
fun FreqDialog(db: Db, init: Freq, onClose: () -> Unit, onSaved: () -> Unit) {
    val acts = remember { db.acts() }
    var f by remember { mutableStateOf(init) }
    var adF by remember { mutableStateOf(init.adF.toString()) }
    var adS by remember { mutableStateOf(init.adS.toString()) }
    var jeF by remember { mutableStateOf(init.jeF.toString()) }
    var jeS by remember { mutableStateOf(init.jeS.toString()) }
    var enf by remember { mutableStateOf(init.enf.toString()) }
    var err by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf(false) }
    fun n(s: String) = s.toIntOrNull()?.coerceAtLeast(0) ?: 0
    @Composable
    fun num(label: String, v: String, set: (String) -> Unit) = OutlinedTextField(
        value = v, onValueChange = { set(it.filter(Char::isDigit)) }, label = { Text(label) }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth()
    )
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (init.id == 0L) "Nouvelle activité" else "Modifier l’activité") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                DateField("Date", f.dateAct, { f = f.copy(dateAct = it) })
                Pick("Activité", acts, acts.firstOrNull { it.id == f.actId }, { it.libelle }) { f = f.copy(actId = it.id) }
                num("Adultes frères", adF) { adF = it }
                num("Adultes sœurs", adS) { adS = it }
                num("Jeunes frères", jeF) { jeF = it }
                num("Jeunes sœurs", jeS) { jeS = it }
                num("Enfants", enf) { enf = it }
                Text("Total : ${n(adF) + n(adS) + n(jeF) + n(jeS) + n(enf)}", fontWeight = FontWeight.Bold)
                OutlinedTextField(value = f.lieu, onValueChange = { f = f.copy(lieu = it) }, label = { Text("Lieu") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = f.intervenant, onValueChange = { f = f.copy(intervenant = it) }, label = { Text("Intervenant") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = f.observation, onValueChange = { f = f.copy(observation = it) }, label = { Text("Observation") }, modifier = Modifier.fillMaxWidth())
                err?.let { Text(it, color = Rouge) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (acts.none { it.id == f.actId }) err = "Choisissez une activité."
                else { db.saveFreq(f.copy(adF = n(adF), adS = n(adS), jeF = n(jeF), jeS = n(jeS), enf = n(enf))); onSaved() }
            }) { Text("Enregistrer") }
        },
        dismissButton = {
            Row {
                if (init.id != 0L) TextButton(onClick = { if (confirm) { db.delFreq(init.id); onSaved() } else confirm = true }) {
                    Text(if (confirm) "Confirmer" else "Supprimer", color = Rouge)
                }
                TextButton(onClick = onClose) { Text("Annuler") }
            }
        }
    )
}

// ======================= RAPPORTS =======================
@Composable
fun RapportScreen(db: Db, tick: Int) {
    val ctx = LocalContext.current
    var debut by remember { mutableStateOf(monthStart()) }
    var fin by remember { mutableStateOf(today()) }
    var devise by remember { mutableStateOf("CDF") }
    val caisse = remember(tick, debut, fin, devise) { rapportCaisse(db, debut, fin, devise) }
    val freq = remember(tick, debut, fin) { rapportFreq(db, debut, fin) }
    val acts = remember(tick, debut, fin) { listeActivites(db, debut, fin) }
    val actNames = remember(tick) { db.acts().associate { it.id to it.libelle } }
    fun export(name: String, content: String) {
        val ok = saveDownload(ctx, name, "text/csv", content)
        Toast.makeText(ctx, if (ok) "Enregistré dans Téléchargements : $name" else "Export impossible", Toast.LENGTH_LONG).show()
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DateField("Du", debut, { debut = it }, Modifier.weight(1f))
            DateField("Au", fin, { fin = it }, Modifier.weight(1f))
        }
        Chips(DEVISES, devise, { it }) { devise = it }

        Section("Caisse par catégorie ($devise)") {
            caisse.forEach {
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                    Text(it.categorie, Modifier.weight(1.4f))
                    Text(fmt(it.entrees), Modifier.weight(1f), color = Vert)
                    Text(fmt(it.sorties), Modifier.weight(1f), color = Rouge)
                    Text(fmt(it.solde), Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                }
            }
            HorizontalDivider()
            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
                Text("Total", Modifier.weight(1.4f), fontWeight = FontWeight.Bold)
                Text(fmt(caisse.sumOf { it.entrees }), Modifier.weight(1f), fontWeight = FontWeight.Bold)
                Text(fmt(caisse.sumOf { it.sorties }), Modifier.weight(1f), fontWeight = FontWeight.Bold)
                Text(fmt(caisse.sumOf { it.solde }), Modifier.weight(1f), fontWeight = FontWeight.Bold)
            }
            Text("Colonnes : entrées, sorties, solde", style = MaterialTheme.typography.bodySmall)
            OutlinedButton(onClick = { export("caisse-$devise-$debut-$fin.csv", csvCaisse(caisse, devise)) }) { Text("Exporter CSV") }
        }

        Section("Fréquentation par activité") {
            Column(Modifier.horizontalScroll(rememberScrollState())) {
                val w = 56.dp
                Row { Text("Activité", Modifier.width(150.dp), fontWeight = FontWeight.Bold)
                    listOf("Nb", "Ad.F", "Ad.S", "Je.F", "Je.S", "Enf.", "Total").forEach { Text(it, Modifier.width(w), fontWeight = FontWeight.Bold) } }
                freq.forEach { r ->
                    Row { Text(r.activite, Modifier.width(150.dp))
                        listOf(r.nb, r.adF, r.adS, r.jeF, r.jeS, r.enf, r.total).forEach { Text(it.toString(), Modifier.width(w)) } }
                }
                HorizontalDivider()
                Row { Text("Total", Modifier.width(150.dp), fontWeight = FontWeight.Bold)
                    listOf(freq.sumOf { it.nb }, freq.sumOf { it.adF }, freq.sumOf { it.adS }, freq.sumOf { it.jeF }, freq.sumOf { it.jeS }, freq.sumOf { it.enf }, freq.sumOf { it.total })
                        .forEach { Text(it.toString(), Modifier.width(w), fontWeight = FontWeight.Bold) } }
            }
            Text("Ad. adultes, Je. jeunes, F frères, S sœurs, Enf. enfants", style = MaterialTheme.typography.bodySmall)
            OutlinedButton(onClick = { export("frequentation-$debut-$fin.csv", csvFreq(freq)) }) { Text("Exporter CSV") }
        }

        Section("Liste des activités") {
            if (acts.isEmpty()) Text("Aucune activité sur cette période.")
            acts.forEach { f ->
                Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Text("${fdate(f.dateAct)} · ${actNames[f.actId] ?: ""}", fontWeight = FontWeight.SemiBold)
                    val detail = listOf(f.lieu, f.intervenant, f.observation).filter { it.isNotBlank() }.joinToString(" · ")
                    if (detail.isNotEmpty()) Text(detail, style = MaterialTheme.typography.bodySmall)
                }
            }
            OutlinedButton(onClick = { export("activites-$debut-$fin.csv", csvActivites(db, acts)) }) { Text("Exporter CSV") }
        }
        Spacer(Modifier.height(12.dp))
    }
}

// ======================= RÉGLAGES =======================
@Composable
fun ReglageScreen(db: Db, tick: Int, bump: () -> Unit) {
    val ctx = LocalContext.current
    var nom by remember(tick) { mutableStateOf(db.eglise()) }
    val cats = remember(tick) { db.cats() }
    val acts = remember(tick) { db.acts() }
    var refDlg by remember { mutableStateOf<Triple<Boolean, Long, String>?>(null) } // (estCategorie, id, libellé)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(value = nom, onValueChange = { nom = it }, label = { Text("Nom de l’église") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { db.setEglise(nom.trim()); bump(); Toast.makeText(ctx, "Nom enregistré", Toast.LENGTH_SHORT).show() }, modifier = Modifier.fillMaxWidth()) { Text("Enregistrer le nom") }

        Section("Catégories de caisse") {
            cats.forEach { c -> Text(c.libelle, Modifier.fillMaxWidth().clickable { refDlg = Triple(true, c.id, c.libelle) }.padding(vertical = 10.dp)) }
            OutlinedButton(onClick = { refDlg = Triple(true, 0L, "") }) { Text("+ Ajouter") }
        }
        Section("Types d’activité") {
            acts.forEach { a -> Text(a.libelle, Modifier.fillMaxWidth().clickable { refDlg = Triple(false, a.id, a.libelle) }.padding(vertical = 10.dp)) }
            OutlinedButton(onClick = { refDlg = Triple(false, 0L, "") }) { Text("+ Ajouter") }
        }
        Section("Sauvegarde") {
            Text("Copie de toutes les données (fichier JSON dans Téléchargements).", style = MaterialTheme.typography.bodySmall)
            OutlinedButton(onClick = {
                val ok = saveDownload(ctx, "eglise-adj-sauvegarde-${today()}.json", "application/json", jsonBackup(db))
                Toast.makeText(ctx, if (ok) "Sauvegarde enregistrée dans Téléchargements" else "Export impossible", Toast.LENGTH_LONG).show()
            }) { Text("Exporter toutes les données") }
        }
        Spacer(Modifier.height(12.dp))
    }

    refDlg?.let { (isCat, id, lib0) ->
        var lib by remember { mutableStateOf(lib0) }
        var err by remember { mutableStateOf<String?>(null) }
        var confirm by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { refDlg = null },
            title = { Text(if (isCat) "Catégorie" else "Type d’activité") },
            text = {
                Column {
                    OutlinedTextField(value = lib, onValueChange = { lib = it }, label = { Text("Libellé") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    err?.let { Text(it, color = Rouge) }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val t = lib.trim()
                    val list = if (isCat) cats else acts
                    when {
                        t.isEmpty() -> err = "Saisissez un libellé."
                        list.any { it.id != id && it.libelle.equals(t, ignoreCase = true) } -> err = "Ce libellé existe déjà."
                        else -> { if (isCat) db.saveCat(id, t) else db.saveAct(id, t); refDlg = null; bump() }
                    }
                }) { Text("Enregistrer") }
            },
            dismissButton = {
                Row {
                    if (id != 0L) TextButton(onClick = {
                        val used = if (isCat) db.catUsage(id) else db.actUsage(id)
                        when {
                            used > 0 -> err = "Impossible : utilisé par $used enregistrement(s)."
                            confirm -> { if (isCat) db.delCat(id) else db.delAct(id); refDlg = null; bump() }
                            else -> confirm = true
                        }
                    }) { Text(if (confirm) "Confirmer" else "Supprimer", color = Rouge) }
                    TextButton(onClick = { refDlg = null }) { Text("Annuler") }
                }
            }
        )
    }
}
