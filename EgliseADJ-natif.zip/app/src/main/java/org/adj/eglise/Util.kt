package org.adj.eglise

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Calendar
import java.util.Locale

val DEVISES = listOf("CDF", "USD")
val MOIS = listOf(
    "janvier", "février", "mars", "avril", "mai", "juin",
    "juillet", "août", "septembre", "octobre", "novembre", "décembre"
)

private val nf = DecimalFormat("#,##0.##", DecimalFormatSymbols(Locale.FRANCE))
fun fmt(d: Double): String = nf.format(d)
fun trimNum(d: Double): String = if (d == Math.floor(d)) d.toLong().toString() else d.toString()

fun fdate(s: String): String {
    val p = s.split("-")
    return if (p.size == 3) "${p[2]}/${p[1]}/${p[0]}" else s
}

fun isoDate(y: Int, m: Int, d: Int) = "%04d-%02d-%02d".format(y, m, d)
fun today(): String {
    val c = Calendar.getInstance()
    return isoDate(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
}
fun monthStart(): String {
    val c = Calendar.getInstance()
    return isoDate(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, 1)
}

// ---------- Rapports (équivalents de qryRapportCaisse, qryRapportFreq, qryRapportActivites) ----------

data class LigneCaisse(val categorie: String, val entrees: Double, val sorties: Double) {
    val solde get() = entrees - sorties
}

data class LigneFreq(
    val activite: String, val nb: Int, val adF: Int, val adS: Int,
    val jeF: Int, val jeS: Int, val enf: Int
) {
    val total get() = adF + adS + jeF + jeS + enf
}

fun rapportCaisse(db: Db, debut: String, fin: String, devise: String): List<LigneCaisse> {
    val ops = db.ops().filter { it.devise == devise && it.dateOp >= debut && it.dateOp <= fin }
    return db.cats().map { c ->
        val mine = ops.filter { it.catId == c.id }
        LigneCaisse(
            c.libelle,
            mine.filter { it.typeOp == "Entrée" }.sumOf { it.montant },
            mine.filter { it.typeOp == "Sortie" }.sumOf { it.montant }
        )
    }
}

fun rapportFreq(db: Db, debut: String, fin: String): List<LigneFreq> {
    val fr = db.freqs().filter { it.dateAct >= debut && it.dateAct <= fin }
    return db.acts().map { a ->
        val m = fr.filter { it.actId == a.id }
        LigneFreq(a.libelle, m.size, m.sumOf { it.adF }, m.sumOf { it.adS }, m.sumOf { it.jeF }, m.sumOf { it.jeS }, m.sumOf { it.enf })
    }
}

fun listeActivites(db: Db, debut: String, fin: String): List<Freq> =
    db.freqs().filter { it.dateAct >= debut && it.dateAct <= fin }.sortedBy { it.dateAct }

// ---------- Export ----------

private fun csvCell(s: Any?): String {
    val t = s?.toString() ?: ""
    return if (t.contains(';') || t.contains('"') || t.contains('\n')) "\"" + t.replace("\"", "\"\"") + "\"" else t
}
fun csv(rows: List<List<Any?>>): String =
    "\uFEFF" + rows.joinToString("\r\n") { r -> r.joinToString(";") { csvCell(it) } }

fun csvCaisse(l: List<LigneCaisse>, devise: String): String {
    val rows = mutableListOf<List<Any?>>(listOf("Catégorie", "Entrées", "Sorties", "Solde"))
    l.forEach { rows.add(listOf(it.categorie, it.entrees, it.sorties, it.solde)) }
    rows.add(listOf("Total $devise", l.sumOf { it.entrees }, l.sumOf { it.sorties }, l.sumOf { it.solde }))
    return csv(rows)
}

fun csvFreq(l: List<LigneFreq>): String {
    val rows = mutableListOf<List<Any?>>(
        listOf("Activité", "Nb", "Adultes frères", "Adultes sœurs", "Jeunes frères", "Jeunes sœurs", "Enfants", "Total")
    )
    l.forEach { rows.add(listOf(it.activite, it.nb, it.adF, it.adS, it.jeF, it.jeS, it.enf, it.total)) }
    rows.add(listOf("Total", l.sumOf { it.nb }, l.sumOf { it.adF }, l.sumOf { it.adS }, l.sumOf { it.jeF }, l.sumOf { it.jeS }, l.sumOf { it.enf }, l.sumOf { it.total }))
    return csv(rows)
}

fun csvActivites(db: Db, l: List<Freq>): String {
    val names = db.acts().associate { it.id to it.libelle }
    val rows = mutableListOf<List<Any?>>(listOf("Date", "Activité", "Lieu", "Intervenant", "Observation"))
    l.forEach { rows.add(listOf(fdate(it.dateAct), names[it.actId] ?: "", it.lieu, it.intervenant, it.observation)) }
    return csv(rows)
}

private fun jsonStr(s: String): String =
    "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "") + "\""

fun jsonBackup(db: Db): String {
    val sb = StringBuilder("{\n")
    sb.append("\"eglise\":").append(jsonStr(db.eglise())).append(",\n")
    sb.append("\"categories\":[").append(db.cats().joinToString(",") { "{\"id\":${it.id},\"libelle\":${jsonStr(it.libelle)}}" }).append("],\n")
    sb.append("\"activites\":[").append(db.acts().joinToString(",") { "{\"id\":${it.id},\"libelle\":${jsonStr(it.libelle)}}" }).append("],\n")
    sb.append("\"caisse\":[").append(db.ops().joinToString(",") {
        "{\"id\":${it.id},\"date\":\"${it.dateOp}\",\"type\":${jsonStr(it.typeOp)},\"categorie\":${it.catId},\"montant\":${it.montant},\"devise\":\"${it.devise}\",\"note\":${jsonStr(it.note)}}"
    }).append("],\n")
    sb.append("\"frequentation\":[").append(db.freqs().joinToString(",") {
        "{\"id\":${it.id},\"date\":\"${it.dateAct}\",\"activite\":${it.actId},\"adF\":${it.adF},\"adS\":${it.adS},\"jeF\":${it.jeF},\"jeS\":${it.jeS},\"enf\":${it.enf},\"lieu\":${jsonStr(it.lieu)},\"intervenant\":${jsonStr(it.intervenant)},\"observation\":${jsonStr(it.observation)}}"
    }).append("]\n}")
    return sb.toString()
}

/** Enregistre un fichier dans le dossier Téléchargements (Android 10+, sans permission). */
fun saveDownload(ctx: Context, name: String, mime: String, content: String): Boolean = try {
    val v = ContentValues().apply {
        put(MediaStore.Downloads.DISPLAY_NAME, name)
        put(MediaStore.Downloads.MIME_TYPE, mime)
        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
    }
    val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
    if (uri == null) false else {
        ctx.contentResolver.openOutputStream(uri)?.use { it.write(content.toByteArray(Charsets.UTF_8)) }
        true
    }
} catch (e: Exception) {
    false
}
