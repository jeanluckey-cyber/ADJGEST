# Église ADJ — application Android native (Kotlin, Jetpack Compose, SQLite)

Reprise de votre application Access en vraie application Android. Fonctionne sans internet.
La base SQLite a les mêmes tables que l'Access : `tblParametre`, `tblCategorie`, `tblActivite`, `tblCaisse`, `tblFrequentation`.

Écrans : Accueil (solde du mois par devise, fréquentation du mois, dernières opérations), Caisse (liste filtrable,
saisie, modification, suppression), Présences (fréquentation), Rapports (caisse par catégorie, fréquentation par
activité, liste des activités, période et devise au choix, export CSV), Réglages (nom de l'église, catégories,
types d'activité, sauvegarde JSON).

Données de départ : nom de l'église, 8 catégories de caisse, 5 types d'activité. Devises : CDF et USD.
Android 10 ou plus requis (les exports vont dans Téléchargements).

## Obtenir le fichier .apk

### Option A — Android Studio (ordinateur)
1. Installez Android Studio (gratuit) et ouvrez ce dossier (`File > Open`).
2. Attendez la fin de la synchronisation Gradle.
3. `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
4. Fichier obtenu : `app/build/outputs/apk/debug/app-debug.apk`. Copiez-le sur le téléphone et ouvrez-le
   (autorisez « Installer des applications inconnues » pour votre gestionnaire de fichiers).

### Option B — Sans rien installer (GitHub)
1. Créez un compte sur github.com et un dépôt vide (privé).
2. Envoyez-y tout le contenu de ce dossier (« Add file > Upload files »), y compris le dossier `.github`.
3. Onglet **Actions** > « Construire l'APK » > attendez la coche verte.
4. Dans l'exécution, section **Artifacts**, téléchargez `EgliseADJ-apk`.

## Remarques
- Le code a été écrit sans pouvoir être compilé dans l'environnement de création. Une petite erreur de compilation
  est possible : envoyez-moi le message affiché et je la corrige.
- Les données restent sur le téléphone. Si vous désinstallez l'application, elles sont perdues :
  utilisez régulièrement Réglages > « Exporter toutes les données ».
- Pas encore prévu : import des données depuis un autre téléphone, mot de passe, gestion de plusieurs utilisateurs.
